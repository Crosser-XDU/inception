批量 boundary / 并行草稿 / 轻量严格验证同步包

本包相对于已经能运行四档 speed 测速的仓库，包含五个运行文件和一个测试文件。
按相对路径复制/解压到集群仓库。覆盖前保留自己填写的 MODEL/CHECKPOINT/DATA/GPU，
或者通过环境变量重新设置；benchmark_decode_start.sh 中的路径仍是占位符。
脚本依赖已有同版本 scripts/run_decode.py 及其余模型代码。无需重训。

export MODEL=/mnt/shared-storage-user/liujinyi/Llama-3-8B-Instruct/snapshots/2b724926966c141d5a60b14e75a5ef5c0ab7a6f0
export CHECKPOINT=/mnt/shared-storage-user/liujinyi/test123/inception/output/core_llama_boundary_0916/checkpoint_output/checkpoint-60375
export DATA="$PWD/data/gsm8k_test.jsonl"
export GPU=0

# 激活与之前相同的 Python 环境，在仓库根目录执行。
python -m unittest discover -s tests -p test_strict_decode.py -v
SPEED_PROFILE=batch bash scripts/benchmark_decode_speed.sh --dry-run
for profile in tmerge batch parallel strict batch_strict parallel_strict; do
  SPEED_PROFILE="$profile" bash scripts/benchmark_decode_speed.sh --samples 32 --block 3 --repeats 1
done

新的五档都以 tmerge 为基础，分别/组合启用三项优化；batch 与 parallel 互斥。
优先比较 fixed 吞吐加速比，同时检查准确率、输出一致率、运行优化计数。
没有测得或保证 1.3 倍性能；GPU 测试及性能需要在集群执行。
本地 66 项测试：65 通过，1 项 CUDA 专用测试跳过。
